% clc 
% clear all
% close all

% 
addpath('D:\PreprocessedData\Class\class_fre4_8_permonth\ASSOM');
addpath('D:\PreprocessedData\HHT_runcode\');
addpath('D:\PreprocessedData\libsvm-3.20\matlab\');

for g=1:1
 %g=1;  
%clearvars -except g error_all test_all error1 error2 test1 test2;

% load('D:\PreprocessedData\Class\MSEntropy\intergood.mat'); %delta
% load('D:\PreprocessedData\Class\MSEntropy\pre.mat'); %delta
inter=double(all_inter);
pre=double(all_pre);

k=3; %k-fold
    
%1.inter-4bands
TRAIN=inter;
w =size(TRAIN,1);
Indices1=crossvalind('Kfold',w,k);%k-fold
test_set_index=(Indices1==1);
train_set_index=~test_set_index;

testing_inter=inter(test_set_index,:);
training_inter=inter(train_set_index,:);    


a=training_inter;
b=testing_inter;
r =size(a,1);
v =size(b,1);

%lable
train_inter_label(1:r,1)=1;
test_inter_label(1:v,1)=1;


%2.pre-4bands!
TRAIN=pre;
w =size(TRAIN,1);
Indices2=crossvalind('Kfold',w,k);%k-fold
test_set_index=(Indices2==1);
train_set_index=~test_set_index;

testing_pre=TRAIN(test_set_index,:);
training_pre=TRAIN(train_set_index,:);       

a=training_pre;
b=testing_pre;
rr =size(a,1);
vv =size(b,1);

%lable
train_pre_lable(1:rr,1)=2;
test_pre_lable(1:vv,1)=2;

%2class
training= [   training_inter ;     training_pre ];
testing = [   testing_inter;     testing_pre ];

train_lable=[train_inter_label;train_pre_lable];
test_lable=[test_inter_label;test_pre_lable];

%% scaling

% tr=size(training,1);
% te=size(testing,1);
% scale=[training;testing];
% newdata = Scaling(scale, 0, 1);
% clear training testing
% 
% training=newdata(1:tr,:);
% testing=newdata(tr+1:tr+te,:);

%% ASSOM
% feature=training;
% label=train_lable;
% 
% positiveLabel=1;%preictal
% negativeLabel=-1;%interictal
% 
% %define:postive is minority
% inputDim=size(feature,2);
% numPos=sum(label==1);%minority
% numNeg=sum(label==-1);
% 
% ratioImb=numNeg/numPos;           
% numMod=ceil(ratioImb)-1;
% numBasis=floor(inputDim*0.8);               
% [trainIns,trainLabel]=ASSOM(feature,label,positiveLabel,numMod,numBasis); 
% %new_data=abs(trainIns);
% new_data=trainIns;
% 
% pos=trainLabel==positiveLabel;
% pre=new_data(pos,:);%new_preictal
% inter=new_data(~pos,:);%new_interictal
% 
% clear training
% training=[inter; pre];

%% NWFE
% feature=10;
% [ivect,ival] = nwfe(training, train_lable,feature);
% training = training*ivect';
% testing= testing*ivect';
%% libsvm  
make;

training=sparse(training);
testing=sparse(testing);

%cmd = ['-t 0']; %linear kernel

%RBF kernel
cmd = ['-c  20 -g 1'];

model = svmtrain(train_lable, training, cmd);

[predict_label, acc, val] = svmpredict(test_lable, testing, model);

% average result
dif_all=find(predict_label ~= test_lable);
dif1=find(predict_label(1:v,1) ~= test_lable(1:v,1));
dif2=find(predict_label(v+1:v+vv,1) ~= test_lable(v+1:v+vv,1));

error_all(g,1)= size(dif_all,1);
error1(g,1)= size(dif1,1);
error2(g,1)= size(dif2,1);

test_all(g,1)= size(test_lable,1);
test1(g,1)= size(test_lable(1:v,1),1);
test2(g,1)= size(test_lable(v+1:v+vv,1),1);

end

std1=1-(error_all./test_all);
std2=std1';
std3=std(std2);

error_all2=sum(error_all);test_all2=sum(test_all);
accuracy_all=1-(error_all2/test_all2);

%preictal:1;interictal:-1
error11=sum(error1); test11=sum(test1);
error22=sum(error2); test22=sum(test2);

accuracy_FT=(error11/test11); % interictal disjudge to preictal
accuracy_TN=(error22/test22); %preictal disjudge to interictal
accuracy_FN=1-accuracy_FT; %interictal to interictal
accuracy_TP=1-accuracy_TN;%preictal to preictal



