clc;clear all;close all;

inter(:,:,:,1)=load('D:\PreprocessedData\channel_data_coherence\01_Interictal\s6\HHT_feature.mat');
inter(:,:,:,2)=load('D:\PreprocessedData\channel_data_coherence\01_Interictal\s11\HHT_feature.mat');
inter(:,:,:,3)=load('D:\PreprocessedData\channel_data_coherence\01_Interictal\s23\HHT_feature.mat');
inter(:,:,:,4)=load('D:\PreprocessedData\channel_data_coherence\01_Interictal\s35\HHT_feature.mat');
inter(:,:,:,5)=load('D:\PreprocessedData\channel_data_coherence\01_Interictal\s43\HHT_feature.mat');
inter(:,:,:,6)=load('D:\PreprocessedData\channel_data_coherence\01_Interictal\s48\HHT_feature.mat');
inter(:,:,:,7)=load('D:\PreprocessedData\channel_data_coherence\01_Interictal\s59\HHT_feature.mat');
inter(:,:,:,8)=load('D:\PreprocessedData\channel_data_coherence\01_Interictal\s73\HHT_feature.mat');
inter(:,:,:,9)=load('D:\PreprocessedData\channel_data_coherence\01_Interictal\s103\HHT_feature.mat');
inter(:,:,:,10)=load('D:\PreprocessedData\channel_data_coherence\01_Interictal\s117\HHT_feature.mat');
inter(:,:,:,11)=load('D:\PreprocessedData\channel_data_coherence\01_Interictal\s126\HHT_feature.mat');
inter(:,:,:,12)=load('D:\PreprocessedData\channel_data_coherence\01_Interictal\s129\HHT_feature.mat');
% inter(:,:,16)=load('D:\PreprocessedData\channel_data_coherence\01_Interictal\s161\HHT_feature.mat');
% inter(:,:,17)=load('D:\PreprocessedData\channel_data_coherence\01_Interictal\s175\HHT_feature.mat');
% inter(:,:,18)=load('D:\PreprocessedData\channel_data_coherence\01_Interictal\s181\HHT_feature.mat');
% inter(:,:,19)=load('D:\PreprocessedData\channel_data_coherence\01_Interictal\s182\HHT_feature.mat');
% inter(:,:,20)=load('D:\PreprocessedData\channel_data_coherence\01_Interictal\s223\HHT_feature.mat');
% inter(:,:,21)=load('D:\PreprocessedData\channel_data_coherence\01_Interictal\s251\HHT_feature.mat');
% inter(:,:,22)=load('D:\PreprocessedData\channel_data_coherence\01_Interictal\s252\HHT_feature.mat');
% inter(:,:,23)=load('D:\PreprocessedData\channel_data_coherence\01_Interictal\s281\HHT_feature.mat');
% inter(:,:,24)=load('D:\PreprocessedData\channel_data_coherence\01_Interictal\s283\HHT_feature.mat');
% inter(:,:,25)=load('D:\PreprocessedData\channel_data_coherence\01_Interictal\s294\HHT_feature.mat');
% inter(:,:,26)=load('D:\PreprocessedData\channel_data_coherence\01_Interictal\s302\HHT_feature.mat');
% inter(:,:,27)=load('D:\PreprocessedData\channel_data_coherence\01_Interictal\s316\HHT_feature.mat');
% inter(:,:,28)=load('D:\PreprocessedData\channel_data_coherence\01_Interictal\s334\HHT_feature.mat');
% inter(:,:,29)=load('D:\PreprocessedData\channel_data_coherence\01_Interictal\s357\HHT_feature.mat');
% inter(:,:,30)=load('D:\PreprocessedData\channel_data_coherence\01_Interictal\s359\HHT_feature.mat');


%----pre data
pre(:,:,:,1)=load('D:\PreprocessedData\channel_data_coherence\02_Preictal\s3\HHT_feature.mat');
pre(:,:,:,2)=load('D:\PreprocessedData\channel_data_coherence\02_Preictal\s29\HHT_feature.mat');
pre(:,:,:,3)=load('D:\PreprocessedData\channel_data_coherence\02_Preictal\s58\HHT_feature.mat');
pre(:,:,:,4)=load('D:\PreprocessedData\channel_data_coherence\02_Preictal\s130\HHT_feature.mat');
pre(:,:,:,5)=load('D:\PreprocessedData\channel_data_coherence\02_Preictal\s143\HHT_feature.mat');
pre(:,:,:,6)=load('D:\PreprocessedData\channel_data_coherence\02_Preictal\s191\HHT_feature.mat');
pre(:,:,:,7)=load('D:\PreprocessedData\channel_data_coherence\02_Preictal\s222\HHT_feature.mat');
pre(:,:,:,8)=load('D:\PreprocessedData\channel_data_coherence\02_Preictal\s266\HHT_feature.mat');
pre(:,:,:,9)=load('D:\PreprocessedData\channel_data_coherence\02_Preictal\s276\HHT_feature.mat');
pre(:,:,:,10)=load('D:\PreprocessedData\channel_data_coherence\02_Preictal\s297\HHT_feature.mat');
pre(:,:,:,11)=load('D:\PreprocessedData\channel_data_coherence\02_Preictal\s313\HHT_feature.mat');
pre(:,:,:,12)=load('D:\PreprocessedData\channel_data_coherence\02_Preictal\s324\HHT_feature.mat');

for k=1:12%inter_num
a=inter(:,:,1,k);
b=a.all_feature;
c=b(:,:,1);%1:open eye!2:closeeye!
d=c';
e=d(:)';
all_inter(k,:)=e;
end

for k=1:12%pre_num
a=pre(:,:,1,k);
b=a.all_feature;
c=b(:,:,1);%1:open eye! 2:closeeye!
d=c';
e=d(:)';
all_pre(k,:)=e;
end

aver_inter=mean(all_inter);
aver_pre=mean(all_pre);